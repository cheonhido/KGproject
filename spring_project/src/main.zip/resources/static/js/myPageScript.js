function initializeMyPage() {
    const postsBtn = document.getElementById('posts-btn');
    const savedBtn = document.getElementById('saved-btn');

    if (!postsBtn || !savedBtn) {
        console.error("Posts or Saved button not found");
        return; // 요소가 없으면 함수를 중단합니다.
    }

    const postsIcon = postsBtn.querySelector('.button-icon');
    const savedIcon = savedBtn.querySelector('.button-icon');

    // 게시물 버튼 클릭 이벤트
    postsBtn.addEventListener('click', function () {
        const postsContainer = document.querySelector('.posts-container');
        const savedContainer = document.querySelector('.saved-container');

        if (postsContainer && savedContainer) {
            postsContainer.classList.add('active');
            savedContainer.classList.remove('active');
            this.classList.add('active');
            savedBtn.classList.remove('active');
        }

        // 게시물 버튼 이미지 변경
        if (postsIcon) postsIcon.src = '/img/menu.png'; // 게시물 버튼 클릭 시 새로운 이미지로 변경
        if (savedIcon) savedIcon.src = '/img/save2.png'; // 저장됨 버튼의 기존 이미지 유지
    });

    // 저장됨 버튼 클릭 이벤트
    savedBtn.addEventListener('click', function () {
        const postsContainer = document.querySelector('.posts-container');
        const savedContainer = document.querySelector('.saved-container');

        if (postsContainer && savedContainer) {
            savedContainer.classList.add('active');
            postsContainer.classList.remove('active');
            this.classList.add('active');
            postsBtn.classList.remove('active');
        }

        // 저장됨 버튼 이미지 변경
        if (savedIcon) savedIcon.src = '/img/save4.png'; // 저장됨 버튼 클릭 시 새로운 이미지로 변경
        if (postsIcon) postsIcon.src = '/img/menu2.png'; // 게시물 버튼의 기존 이미지 유지
    });
}
