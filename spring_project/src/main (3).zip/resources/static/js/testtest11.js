(function() {
	// 초기화 함수
	function initializePage() {
		// 모든 a 요소를 가져옵니다.
		const menuItems = document.querySelectorAll('.left-section a');
		const slideOuts = document.querySelectorAll('.slide-out');
		const leftSection = document.querySelector('.left-section');
		const logoButton = document.getElementById('logoButton');
		const homeButton = document.getElementById('homeButton');

		// 로고 클릭 시 페이지 새로고침
		if (logoButton) {
			logoButton.addEventListener('click', function(event) {
				event.preventDefault();
				location.reload();
			});
		}

		// 홈 버튼 클릭 시 페이지 새로고침
		if (homeButton) {
			homeButton.addEventListener('click', function(event) {
				event.preventDefault();
				location.reload();
			});
		}

		// 슬라이드 패널 관련 이벤트 설정
		menuItems.forEach(item => {
			item.addEventListener('click', function(event) {
				event.preventDefault();
				slideOuts.forEach(slide => slide.classList.remove('active'));
				const slideId = this.getAttribute('data-slide');
				const slideOut = document.getElementById(slideId);
				if (slideOut) slideOut.classList.add('active');
			});
		});

		// 외부 클릭 시 슬라이드 아웃 섹션 닫기
		document.addEventListener('click', function(event) {
			if (!event.target.closest('.left-section')) {
				slideOuts.forEach(slide => slide.classList.remove('active'));
				leftSection.classList.remove('collapsed');
			}
		});

		// 팔로우 버튼 이벤트 처리
		initializeFollowButtons();

		// SendMessageForm 이벤트 처리
		initializeSendMessageForm();

		// 좋아요 버튼 처리
		initializeLikeButtons();

		// 저장 버튼 처리
		initializeSaveButtons();
	}

	// 팔로우 버튼 초기화
	function initializeFollowButtons() {
		document.querySelectorAll(".followBtn").forEach(function(button) {
			button.addEventListener("click", function() {
				var toUserValue = this.closest("tr").querySelector("[data-userid]").getAttribute("data-userid");
				document.getElementById("hidden_to_user").value = toUserValue;
				var xhr = new XMLHttpRequest();
				xhr.open("POST", "/follow", true);
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xhr.onreadystatechange = function() {
					if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
						button.value = "팔로잉";
						button.disabled = true;
						button.style.color = "#212121";
					} else {
						alert("팔로우 요청 중 오류가 발생했습니다.");
					}
				};
				xhr.send("to_user=" + encodeURIComponent(toUserValue));
			});
		});
	}

	// SendMessageForm 초기화
	function initializeSendMessageForm(friendList) {
		const toUserInput = document.getElementById('toUserInput');
		const suggestionList = document.getElementById('suggestionList');

		if (!toUserInput || !suggestionList) return;

		toUserInput.addEventListener('input', function() {
			const inputValue = toUserInput.value.toLowerCase();
			suggestionList.innerHTML = ''; // 기존 리스트 초기화

			if (inputValue && friendList) {
				const filteredFriends = friendList.filter(friend =>
					friend.username.toLowerCase().includes(inputValue) ||
					friend.userid.toLowerCase().includes(inputValue)
				);

				filteredFriends.forEach(friend => {
					const listItem = document.createElement('li');
					listItem.innerHTML = `<div style="display: flex; align-items: center;">
                        <img src="/storage/${friend.pfimage}" alt="${friend.username}" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;">
                        <div>
                            <div style="font-weight: bold;">${friend.username}</div>
                            <div style="color: #888;">${friend.userid}</div>
                        </div>
                    </div>`;
					listItem.addEventListener('click', () => {
						toUserInput.value = friend.userid;
						suggestionList.innerHTML = '';
					});
					suggestionList.appendChild(listItem);
				});
			}
		});
	}

	// 좋아요 버튼 초기화
	function initializeLikeButtons() {
		document.querySelectorAll('.heart-button').forEach(button => {
			button.addEventListener('click', function() {
				const postSeq = button.dataset.postSeq;
				const isLiked = button.dataset.isLiked === 'true';
				likePost(postSeq, isLiked, button);
			});
		});
	}

	function likePost(postSeq, isLiked, button) {
		const url = isLiked ? '/unlikePost' : '/likePost';
		fetch(url, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				post_seq: postSeq
			})
		})
			.then(response => response.json())
			.then(data => {
				if (data.status === 'success') {
					document.getElementById(`likesCount-${postSeq}`).innerText = data.likeCount;
					const heartImage = document.getElementById(`heart1Image-${postSeq}`);
					heartImage.src = isLiked ? 'img/heart1.png' : 'img/heart2.png';
					button.dataset.isLiked = !isLiked;
				}
			})
			.catch(error => console.error('Error:', error));
	}

	// 게시글 저장 버튼 초기화
	function initializeSaveButtons() {
		document.querySelectorAll('.save-button').forEach(button => {
			button.addEventListener('click', function() {
				const postSeq = this.dataset.postSeq;
				const isSaved = this.dataset.isSaved === 'true';
				toggleSave(postSeq, isSaved, button);
			});
		});
	}

	function toggleSave(postSeq, isSaved, button) {
		fetch(`/toggleSavePost/${postSeq}`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			body: new URLSearchParams({
				post_seq: postSeq
			})
		})
			.then(response => response.json())
			.then(data => {
				const saveImage = document.getElementById(`saveImage-${postSeq}`);
				saveImage.src = isSaved ? 'img/save.png' : 'img/save5.png';
				button.dataset.isSaved = !isSaved;
			})
			.catch(error => console.error('Error:', error));
	}

	// 페이지가 로드될 때마다 initializePage 실행
	document.addEventListener('DOMContentLoaded', initializePage);

	// 동적으로 MyPage 등의 HTML을 로드한 후 다시 초기화
	function updateSectionsAfterLoad(html) {
		document.querySelector('.feed-section').innerHTML = html;
		initializePage();  // 다시 초기화
	}

	window.updateSectionsAfterLoad = updateSectionsAfterLoad;
})();
