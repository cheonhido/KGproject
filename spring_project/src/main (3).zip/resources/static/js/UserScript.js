function IdPwdCheck() {
	var frm = document.loginForm;

	if (!frm.userid.value.trim()) {
		alert("아이디를 입력해주세요");
		frm.userid.value = "";
		frm.userid.focus();
		return false;
	}
	if (!frm.userpwd.value.trim()) {
		alert("비밀번호를 입력해주세요");
		frm.userpwd.value = "";
		frm.userpwd.focus();
		return false;
	}
	frm.submit();
}

function changePicture(id) {
    // 새 창 크기 설정
    var width = 500;  // 너비
    var height = 300;  // 높이
	
    // 현재 창 크기 가져오기
    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;

    // 창의 위치 계산
    var left = (windowWidth - width) / 2;
    var top = (windowHeight - height) / 2;

    // 새 창 열기
    var features = `width=${width},height=${height},left=${left},top=${top},scrollbars=yes,resizable=yes`;
    window.open("/changePicture?userid=" + id, "", features);
}

function changePicture2(id) {
    // 새 창 크기 설정
    var width = 500;  // 너비
    var height = 300;  // 높이
	
    // 현재 창 크기 가져오기
    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;

    // 창의 위치 계산
    var left = (windowWidth - width) / 2;
    var top = (windowHeight - height) / 2;

    // 새 창 열기
    var features = `width=${width},height=${height},left=${left},top=${top},scrollbars=yes,resizable=yes`;
    window.open("/changePicture2?userid=" + id, "", features);
}