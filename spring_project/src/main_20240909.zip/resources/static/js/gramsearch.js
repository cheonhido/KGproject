document.addEventListener('DOMContentLoaded', function() {
	if (typeof loginedId !== 'undefined' && loginedId !== null) {
		// console.log("Logged in user:", loginedId);

		const searchTextField = document.getElementById('search_textField');
		const searchResultDiv = document.getElementById('print_search_result');

		// Spring에서 넘겨받은 데이터를 JSON으로 파싱
		allUserList = JSON.parse(allUserList); // 문자열을 배열로 변환

		if (searchTextField) {
			searchTextField.addEventListener('input', function() {
				const searchValue = this.value.trim().toLowerCase(); // 검색어를 소문자로 변환
				searchResultDiv.innerHTML = ''; // 기존 결과를 초기화

				// 만약 검색어가 '#'으로 시작한다면 서버로 AJAX 요청
				if (searchValue.startsWith('#') && searchValue.length > 1) {
					// AJAX를 사용하여 서버로 해시태그 검색 요청
					const hashtag = searchValue.substring(1); // '#' 제거
					const xhr = new XMLHttpRequest();
					xhr.open('GET', `/searchHashtagInfo?hashtagName=${encodeURIComponent(hashtag)}`, true);
					xhr.onreadystatechange = function() {
						if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
							// 서버에서 받은 해시태그 검색 결과를 처리
							const postsGroupedByHashtag = JSON.parse(xhr.responseText); // 서버 응답을 JSON으로 파싱

							// 해시태그별로 게시글을 렌더링
							for (const [hashtag, posts] of Object.entries(postsGroupedByHashtag)) {
								const hashtagHeader = document.createElement('h4');
								hashtagHeader.textContent = `#${hashtag}`;
								searchResultDiv.appendChild(hashtagHeader);

								if (posts.length > 0) {
								    // 해시태그별 게시물 개수 출력
								    const postElement = document.createElement('div');
								    postElement.innerHTML = `<p>게시물 ${posts.length}개</p>`;
								    searchResultDiv.appendChild(postElement);
								}
							}
						}
					};
					xhr.send();
					return; // 서버 요청 후 종료
				}

				// 검색어가 '#'으로 시작하지 않을때 로직
				if (searchValue === '') {
					searchResultDiv.innerHTML = '<h4>최근 검색 내역 없음.</h4>';
					return;
				}

				// userid나 username에 검색어가 포함된 유저 필터링
				const filteredUsers = allUserList.filter(user =>
					(user.userid.toLowerCase().includes(searchValue) ||
						user.username.toLowerCase().includes(searchValue)) &&
					user.userid !== loginedId
				);

				// 필터링된 유저 출력
				if (filteredUsers.length > 0) {
					filteredUsers.forEach(user => {
						const userElement = document.createElement('div');
						userElement.style.display = 'flex';
						userElement.style.alignItems = 'center';
						userElement.style.marginBottom = '10px';

						// 프로필 이미지
						const imgElement = document.createElement('img');
						imgElement.src = `/storage/${user.pfimage}`;
						imgElement.alt = `${user.username}'s profile image`;
						imgElement.style.width = '40px';
						imgElement.style.height = '40px';
						imgElement.style.borderRadius = '50%';
						imgElement.style.marginRight = '10px'; // 이미지와 텍스트 사이 여백

						// 유저 정보 (ID와 이름)
						const userInfo = document.createElement('h4');
						userInfo.innerHTML = `${user.userid} <br> ${user.username}`;

						// 클릭 시 해당 유저의 mypage로 이동
						userElement.addEventListener('click', function() {
							window.location.href = `/MyPage?pageid=${user.userid}`; // 해당 유저의 mypage로 이동
						});

						// 프로필 이미지와 유저 정보를 같이 출력
						userElement.appendChild(imgElement);
						userElement.appendChild(userInfo);

						searchResultDiv.appendChild(userElement); // 검색 결과를 출력 영역에 추가
					});
				} else {
					// searchResultDiv.innerHTML = '<h4>검색 결과가 없습니다.</h4>';
				}
			});
		}
	} else {
		console.log("from_user is not defined or null");
	}
});
