package com.example.spring_project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.spring_project.dao.InstaboardDAO;
import com.example.spring_project.dto.InstaboardDTO;
import com.example.spring_project.entity.InstaComment;
import com.example.spring_project.entity.Instaboard;
import com.example.spring_project.repository.InstaboardRepository;

import jakarta.transaction.Transactional;

@Service
public class InstaboardService {
	@Autowired
	private InstaboardDAO dao;
	@Autowired
	private InstaboardRepository instaboardRepository;
	
	//---------------------------------------------------------------//
public Instaboard insertImage(String userId, List<String> board_file) {
		
        return dao.insertImage(userId, board_file);
		
	}
	
	// 기능은 수정이지만 사용은 입력으로 사용
	public Instaboard insertContent(int seq, String userId, InstaboardDTO dto) {
		
		
		return dao.insertContent(seq, userId, dto);
	}
	
	// 리스트로 전체 불러오기
	public List<Instaboard> instaList(String userid) {
		
		return dao.instaList(userid);
	}
	
	// 게시글 삭제
	public int instaboardDelete(int seq) {
		return dao.instaboardDelete(seq);
	}
	
	// 게시글 한개 조회
	
	public Instaboard findBoard(int seq) {
		return dao.findBoard(seq);
	}
	
	// 댓글 달기
	public InstaComment insertComment(String userId, String content, int instaboardSeq) {
			
	    return dao.insertComment(userId, content, instaboardSeq);
	}
		
	// 특정 게시글의 달린 댓글들 조회
	public List<InstaComment> getCommentByBoardSeq(int seq) {
		Instaboard instaboard = instaboardRepository.findById(seq).orElse(null);
        return dao.getBoardWithComments(instaboard);
	}
		
	// 댓글 삭제
	@Transactional
	public int deleteComment(int getId, String userid) {
		return dao.deleteComment(getId, userid);
	}
	
	// 좋아요 기능 구현
	
	// 좋아요 추가
	@Transactional
	public boolean likePost(String userid, int instaboard) {
		return dao.likePost(userid, instaboard);
	}
		
	// 좋아요 취소
	@Transactional
	public boolean unlikePost(String userid, int instaboard) {
		return dao.unlikePost(userid, instaboard);
	}
		
	// 좋아요 수 조회
	public int getLikeCount(int instaboard) {
		return dao.getLikeCount(instaboard);
	}
	
	// 사용자가 좋아요한 게시글 목록 가져오기
	public List<Integer> getLikedPostIds(String userid) {
		return dao.getLikedPostIds(userid);
	}

	// 이하 은택------------------------------------------------------//
	public int countPostsByUserId(String userid) {
		return dao.countPostsByUserId(userid);
	}

	// 게시물 리스트 구하기
	public List<String> getUserImages(String userid) {
		return dao.getUserImages(userid);
	}

	// 이하 석호---------------------------------------------------------//
	public List<Instaboard> instaListAll() {
		return dao.instaListAll();
	}
}
